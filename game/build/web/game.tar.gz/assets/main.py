import pygame
import random
import math
import asyncio

async def main():
    pygame.init()
    WIDTH = 600
    HEIGHT = 400
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()


    class asteroid:
        def __init__(self):
            self.vec = pygame.math.Vector2(random.randint(100, 500), random.randint(100, 300))
            self.vecmove = pygame.math.Vector2(random.randint(1, 3), random.randint(1, 3))
            self.radius = random.randint(10, 30)
            self.id = random.randint(0, 999)

    class spaceship:
        def __init__(self):
            self.pos = pygame.math.Vector2(300, 200)
            self.hitbox = pygame.Rect(self.pos.x - 9, self.pos.y, 20, 20)
            self.dir = pygame.math.Vector2(0, 1)
            self.angle = 0
            self.basetri = [
            pygame.math.Vector2(0, -15),
            pygame.math.Vector2(-15, 20),
            pygame.math.Vector2(15, 20)]
            self.vel = pygame.math.Vector2(0, 0)
            self.accel = 0.15
            self.drag = 0.99
            self.speedlim = 6
            self.hits = 3

        def forward(self):
            return pygame.math.Vector2(0, -1).rotate(self.angle)

        def update(self, thrust):
            if thrust:
                self.vel += self.accel * self.forward()
                if self.vel.length() > self.speedlim:
                    self.vel.scale_to_length(self.speedlim)
            self.vel *= self.drag
            self.pos += self.vel
            self.hitbox.center = self.pos

        def points(self):
            return[self.pos + p.rotate(self.angle) for p in self.basetri]

    class square_alien:
        def __init__(self, x, y):
            self.pos = pygame.math.Vector2(x, y)
            self.angle = 0
            self.detected = False
            self.chase_speed = 1.3
            self.ambient_speed = 1
            self.viewrange = 150
            self.ignore_timer = 0
            self.turn = 0.03

        def forward(self):
            return pygame.math.Vector2(math.cos(self.angle), -math.sin(self.angle))
        def track(self, player):
            player_dist = (player.pos - self.pos)
            distance = player_dist.length()
            if distance == 0:
                return
            player_dir = player_dist/distance
            self_forward = self.forward()
            dot = self_forward.dot(player_dist)

            in_fov = False
            if dot > 0.7:
                in_fov = True

            distance = self.pos.distance_to(player.pos)
            in_dist = False
            if distance < self.viewrange:
                in_dist = True

            if in_dist and in_fov:
                self.detected = True
                self.ignore_timer = 90
            elif self.ignore_timer > 0:
                self.ignore_timer -= 1
            else:
                self.detected = False

            if self.detected == True:
                self.angle = math.atan2(-player_dir.y, player_dir.x)
                self.pos += player_dir * self.chase_speed
            else:
                if random.random() < 0.03:
                    self.turn = random.uniform(-0.05, 0.05)
                    self.angle += self.turn
                    self.pos += self.forward() * self.ambient_speed
                if not (20 < self.pos.x < 580 and 20 < self.pos.y < 380):
                    dist_center = pygame.math.Vector2(300, 200) - self.pos
                    self.angle = math.atan2(-dist_center.y, dist_center.x)


    class GameManager:
        def __init__(self):
            self.bull_cd = 0
            self.hit_cd = 50
        def upd(self):
            self.bull_cd -= 1
        def activate_hittimer(self):
            self.hit_cd -= 1
        def bull_zero(self):
            self.bull_cd = 0
        def bull_reset(self):
            self.bull_cd = 10
        def hit_reset(self):
            self.hit_cd = 50

    class bullet:
        def __init__(self, player):
            self.vec = player.forward() * 5
            self.pos = pygame.math.Vector2(player.pos)
        def update(self, mgnr):
            self.pos += self.vec
            if mgnr.bull_cd == 0:
                pass
            
    asteroids = [asteroid(), asteroid(), asteroid(), asteroid(), asteroid(), asteroid()]
    enemies = [square_alien(100, 200)]
    ship = spaceship()
    bullets = []
    manager = GameManager()

    gameloop = True

    while gameloop:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameloop = False

        screen.fill((0, 0, 0))

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]: #keys inpuits
            ship.angle -= 5
        if keys[pygame.K_RIGHT]:
            ship.angle += 5
        if keys[pygame.K_f]:
            if manager.bull_cd <= 0:
                bullets.append(bullet(ship))
                manager.bull_reset()
        if keys[pygame.K_UP]:
            ship.update(True)
        elif not keys[pygame.K_UP]:
            ship.vel *= 0.2

        pygame.draw.polygon(screen, (150, 147, 147), ship.points())

        for i, ast in enumerate(asteroids):
            pygame.draw.circle(screen, ((88, 149, 173)), (ast.vec.x, ast.vec.y), ast.radius)
            ast.vec += ast.vecmove
            if ast.vec.x + ast.radius > 600 or 0 > ast.vec.x - ast.radius:
                ast.vecmove.x *= -1 
            if ast.vec.y + ast.radius > 400 or 0 > ast.vec.y - ast.radius:
                ast.vecmove.y *= -1

            pos_dif = ship.pos - ast.vec
            if pos_dif.length() <= ast.radius + ship.hitbox.width:
                if manager.hit_cd <= 0:
                    ship.hits -= 1
                    manager.hit_reset()

            for bull in bullets:
                dif = ast.vec - bull.pos
                if ast.radius >= dif.length():
                    asteroids[i] = asteroid()
                    bullets.remove(bull)
                
            for other in asteroids:
                if other.id != ast.id:
                    vecdif = other.vec - ast.vec
                    if 0 < vecdif.length() <= ast.radius + other.radius:
                        vecdif = vecdif.normalize()
                        spd = (ast.vecmove - other.vecmove).dot(vecdif)
                        if spd > 0:
                            ast.vecmove -= vecdif * spd
                            other.vecmove += vecdif * spd

        for enemy in enemies:
            enemy.track(ship)
            guy = pygame.Rect(enemy.pos.x - 30, enemy.pos.y - 30, 30, 30)
            pygame.draw.rect(screen, ((88, 149, 173)), guy)
            if guy.colliderect(ship.hitbox):
                if manager.hit_cd <= 0:
                    ship.hits -= 1
                    manager.hit_reset()

        for bull in bullets:
            bull.update(manager)
            pygame.draw.circle(screen, (0, 255, 0), (bull.pos.x, bull.pos.y), 3)
        if manager.bull_cd > 0:
            manager.upd()

        if ship.pos.x > WIDTH:
            ship.pos.x = 0
        elif ship.pos.x < 0:
            ship.pos.x = WIDTH
        if ship.pos.y > HEIGHT:
            ship.pos.y = 0
        elif ship.pos.y < 0:
            ship.pos.y = HEIGHT


        manager.activate_hittimer()

        if ship.hits <= 0:
            font_render = font.render("GAME OVER", True, (255, 255, 255))
            screen.blit(font_render, (WIDTH/2 - 100, HEIGHT/2 - 20))
            temp = clock.get_time()
            if clock.get_time() - temp >= 300:
                pygame.quit()
        else:
            font = pygame.font.Font(None, 48)
            font_render = font.render(f"Lives: {ship.hits}", True, (255, 255, 255))
            screen.blit(font_render, (10, 10))
        
        clock.tick(30)
        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()
asyncio.run(main())